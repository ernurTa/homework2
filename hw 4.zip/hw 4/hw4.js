const arr = [{
    name: "nurbol",
    lastName:"i dont know",
    age:"13"
    },{
     name:"era",
     lastName: "i dont know",
    age: "14"
    },{
     name:"Adi",
     lastName:"I dont know",
     age: "17"
    }]
    
    
    console.log(arr[0].name, arr[1].name, arr[2].name);
    
    
    for(let num=0; num<=20; num+=1 ) console.log(num);